﻿
using System;
using System.Collections.Generic;

namespace Blackjack
{

    public enum CardSuit
    {
        Spades,
        Hearts,
        Clubs,
        Diamonds
    }
    public enum CardFace
    {
        A,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        J,
        Q,
        K
    }

    public class Card
    {
        public CardSuit suit { get; set; }
        public CardFace face { get; set; }
        public Card(CardFace face, CardSuit suit)
        {
            this.face = face;
            this.suit = suit;
        }

        public void Print(int x, int y)
        {
            char cardd = 'c';

            if (this.suit == CardSuit.Hearts)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                cardd = '\u2665';
            }
            else if (this.suit == CardSuit.Diamonds)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                cardd = '\u2666';
            }
            else if (this.suit == CardSuit.Spades)
            {
                Console.ForegroundColor = ConsoleColor.Black;
                cardd = '\u2660';
            }
            else if (this.suit == CardSuit.Clubs)
            {
                Console.ForegroundColor = ConsoleColor.Black;
                cardd = '\u2663';
            }

            Console.BackgroundColor = ConsoleColor.White;

            if (face == CardFace.A)
                Console.Write("{0} {1}", "A", cardd);
            else if (face == CardFace.Two)
                Console.Write("{0} {1}", "2", cardd);
            else if (face == CardFace.Three)
                Console.Write("{0} {1}", "3", cardd);
            else if (face == CardFace.Four)
                Console.Write("{0} {1}", "4", cardd);
            else if (face == CardFace.Five)
                Console.Write("{0} {1}", "5", cardd);
            else if (face == CardFace.Six)
                Console.Write("{0} {1}", "6", cardd);
            else if (face == CardFace.Seven)
                Console.Write("{0} {1}", "7", cardd);
            else if (face == CardFace.Eight)
                Console.Write("{0} {1}", "8", cardd);
            else if (face == CardFace.Nine)
                Console.Write("{0} {1}", "9", cardd);
            else if (face == CardFace.Ten)
                Console.Write("{0} {1}", "10", cardd);
            else if (face == CardFace.J)
                Console.Write("{0} {1}", "J", cardd);
            else if (face == CardFace.Q)
                Console.Write("{0} {1}", "Q", cardd);
            else if (face == CardFace.K)
                Console.Write("{0} {1}", "K", cardd);
            Console.ResetColor();
            Console.Write(" ");


        }
    }

    public class BlackjackCard : Card
    {
        public BlackjackCard(CardFace face, CardSuit suit) : base(face, suit)
        {
        }
        public int Value
        {
            get
            {
                if (face == CardFace.A)
                    return Value = 1;
                else if (face == CardFace.Two)
                    return Value = 2;
                else if (face == CardFace.Three)
                    return Value = 3;
                else if (face == CardFace.Four)
                    return Value = 4;
                else if (face == CardFace.Five)
                    return Value = 5;
                else if (face == CardFace.Six)
                    return Value = 6;
                else if (face == CardFace.Seven)
                    return Value = 7;
                else if (face == CardFace.Eight)
                    return Value = 8;
                else if (face == CardFace.Nine)
                    return Value = 9;
                else if (face == CardFace.Ten)
                    return Value = 10;
                else if (face == CardFace.J)
                    return Value = 10;
                else if (face == CardFace.Q)
                    return Value = 10;
                else if (face == CardFace.K)
                    return Value = 10;
                else
                    return 0;
            }
            set { }

        }

    }


    public static class CardFactory
    {
        public static Card CreateCard(Blackjack.CardFace face, Blackjack.CardSuit suit)
        {
            return new Card(face, suit);
        }

        //Add a new method to the Card Factory that will create an instance of the BlackjackCard
        public static BlackjackCard CreateBlackjackCard(Blackjack.CardFace face, Blackjack.CardSuit suit)
        {
            return new BlackjackCard(face, suit);
        }
    }



    public class Deck
    {
        protected List<Card> cards = new List<Card>();
        public Deck()
        {
            CreateAllCards();
        }
        public virtual void CreateAllCards()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 13; j++)
                {
                    cards.Add(CardFactory.CreateCard((Blackjack.CardFace)j, (Blackjack.CardSuit)i));
                }
            }
        }
        public void Shuffle()
        {
            Random rnd = new();
            for (int i = 0; i < cards.Count; i++)
            {
                int j = rnd.Next(cards.Count);
                (cards[j], cards[i]) = (cards[i], cards[j]);
            }
        }
        public Card? Deal()
        {
            Shuffle();

            if (cards.Count > 0)
            {
                Card c = cards[0];
                cards.RemoveAt(0);
                return c;
            }
            else
            {
                return null;
            }
        }

        public void Print()
        {
            for (int i = 0; i < cards.Count; i++)
            {
                cards[i].Print(i, cards.Count);
                if (i == 12 || i == 25 || i == 38)
                    Console.WriteLine();
            }
        }
    }

    public class BlackjackDeck : Deck
    {
        public BlackjackDeck()
        {
            CreateAllCards();
        }

        // override CreateAllCards
        public override void CreateAllCards()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 13; j++)
                {
                    cards.Add(CardFactory.CreateBlackjackCard((Blackjack.CardFace)j, (Blackjack.CardSuit)i));
                }
            }
        }
    }



    public class Hand
    {
        protected List<Card> _cards = new();
        public virtual void AddCard(Card card)
        {
            _cards.Add(card);
        }
        public virtual void Print(int x, int y)
        {
            foreach (Card card in _cards)
            {
                card.Print(x, y);
                x += 2;
            }
        }

        public virtual void clear()
        {
            _cards.Clear();
        }
    }

    public class BlackjackHand : Hand
    {

        public int _Score
        {
            get
            {
                int score = 0;
                foreach (BlackjackCard card in _cards)
                {
                    score += card.Value;
                }

                return score;
            }
            set { }
        }

        public bool _IsDealer { get; set; } = false;

        public BlackjackHand(bool? isDealer = false)
        {
            if (isDealer.HasValue)
            {
                _IsDealer = isDealer.Value;
            }
            _cards = new List<Card>();
        }
        public override void AddCard(Card card)
        {
            base.AddCard(card);
            if (_Score > 21)
            {
                foreach (BlackjackCard blackjackCard in _cards)
                {
                    if (blackjackCard.Value == 11)
                    {
                        blackjackCard.Value = 1;
                    }
                }
            }
        }

        public override void Print(int x, int y)
        {
            if (_IsDealer)
            {
                Console.BackgroundColor = ConsoleColor.Cyan;
                Console.Write("   ");
                x += 2;
                Console.ResetColor();
                Console.Write(" ");

                for (int i = 1; i < _cards.Count; i++)
                {
                    _cards[i].Print(x, y);
                    x += 2;
                }
                Console.WriteLine("??");
            }
            else
            {
                base.Print(x, y);
                Console.WriteLine(_Score);
            }
        }

        public override void clear()
        {
            base.clear();
            _Score = 0;
        }

        public void Reveal(int x, int y)
        {
            if (_IsDealer)
            {
                _IsDealer = false;
                Print(x, y);
                _IsDealer = true;
            }
            else
            {
                Print(x, y);
            }
        }

    }


    // main
    public class Program
    {
        public static void Main(string[] args)
        {
            BlackjackDeck deck = new BlackjackDeck();
            BlackjackHand playerHand = new BlackjackHand();
            BlackjackHand dealerHand = new BlackjackHand(true);

            // deal 2 cards to player
            playerHand.AddCard(deck.Deal());
            playerHand.AddCard(deck.Deal());

            // deal 2 cards to dealer
            dealerHand.AddCard(deck.Deal());
            dealerHand.AddCard(deck.Deal());

            // print hands
            playerHand.Print(0, 0);
            dealerHand.Print(0, 0);

            // player turn
            while (playerHand._Score < 21)
            {
                Console.WriteLine("Hit or Stand? (h/s)");
                string input = Console.ReadLine();
                if (input == "h")
                {
                    playerHand.AddCard(deck.Deal());
                    playerHand.Print(0, 0);
                }
                else if (input == "s")
                {
                    break;
                }
            }

            // dealer turn
            while (dealerHand._Score < 17)
            {
                dealerHand.AddCard(deck.Deal());
                dealerHand.Print(0, 0);
            }

            // reveal dealer hand
            dealerHand.Reveal(0, 0);

            // determine winner
            if (playerHand._Score > 21)
            {
                Console.WriteLine("Dealer Wins!");
            }
            else if (dealerHand._Score > 21)
            {
                Console.WriteLine("Player Wins!");
            }
            else if (playerHand._Score > dealerHand._Score)
            {
                Console.WriteLine("Player Wins!");
            }
            else if (playerHand._Score < dealerHand._Score)
            {
                Console.WriteLine("Dealer Wins!");
            }
            else
            {
                Console.WriteLine("Tie!");
            }

            Console.ReadLine();
        }
        
    }
    // namespace Blackjack
}
